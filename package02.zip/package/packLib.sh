#!/bin/sh
cp /usr/lib/libCypher4SLP.so.1*	 ./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libQt5Charts.so.5*	./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libQt5Widgets.so.5* 	./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libQt5Gui.so.5* 	./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libQt5Network.so.5* 	./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libQt5Core.so.5* 	./  -rdf
cp /usr/lib/x86_64-linux-gnu/libstdc++.so.6* 	./  -rdf
cp /lib/x86_64-linux-gnu/libgcc_s.so.1* 				./  -rdf
cp /lib/x86_64-linux-gnu/libpthread.so.0 /lib/x86_64-linux-gnu/libpthread-2.23.so               ./  -rdf
cp /usr/lib/x86_64-linux-gnu/mesa/libGL.so.1*           ./  -rdf
cp /lib/x86_64-linux-gnu/libm.so.6        /lib/x86_64-linux-gnu/libm-2.23.so               ./  -rdf
cp /lib/x86_64-linux-gnu/libz.so.1*                     ./  -rdf
cp /lib/x86_64-linux-gnu/libdl.so.2   /lib/x86_64-linux-gnu/libdl-2.23.so                  ./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libicui18n.so.56*    ./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libicuuc.so.56*      ./  -rdf
cp /home/dj/Qt5.14.2/5.14.2/gcc_64/lib/libicudata.so.56*    ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libgthread-2.0.so.0*       ./  -rdf
cp /lib/x86_64-linux-gnu/libglib-2.0.so.0*              ./  -rdf
cp /lib64/ld-linux-x86-64.so.2  /lib/x86_64-linux-gnu/ld-2.23.so                        ./  -rdf
cp /lib/x86_64-linux-gnu/libexpat.so.1*                 ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb-dri3.so.0*          ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb-present.so.0*       ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb-sync.so.1*          ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxshmfence.so.1*         ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libglapi.so.0*             ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXext.so.6*              ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXdamage.so.1*           ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXfixes.so.3*            ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libX11-xcb.so.1*           ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libX11.so.6*               ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb-glx.so.0*           ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb-dri2.so.0*          ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libxcb.so.1*               ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXxf86vm.so.1*           ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libdrm.so.2*               ./  -rdf
cp /lib/x86_64-linux-gnu/libpcre.so.3*                  ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXau.so.6*               ./  -rdf
cp /usr/lib/x86_64-linux-gnu/libXdmcp.so.6*             ./  -rdf
