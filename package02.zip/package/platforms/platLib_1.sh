#!/bin/sh
exe="libqxcb.so"
deplist=$(ldd $exe | awk '{if(match($3,"/")){printf("%s "),$3}}')
echo $deplist
